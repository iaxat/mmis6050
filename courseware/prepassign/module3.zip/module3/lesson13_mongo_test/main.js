const MongoDB = require("mongodb").MongoClient,    
  dbURL = "mongodb+srv://axat:axat123@cluster0.y9onm.mongodb.net/recipe_db?retryWrites=true&w=majority",
  dbName = "recipe_db";

MongoDB.connect(dbURL, (error, client) => {        
  if (error) throw error;
  let db = client.db(dbName);                      
  db.collection("contacts")
    .find()
    .toArray((error, data) => {                    
      if (error) throw error;
      console.log(data);                           
    });
});